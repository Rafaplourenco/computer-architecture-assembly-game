; Computer Architecture Academic Project
; Instituto Superior Tecnico
; Group project

; -------------------------------------------------------------
; *********************** CONSTANTES **************************
; -------------------------------------------------------------
DISPLAYS          EQU 0A000H    
TEC_LIN           EQU 0C000H    
TEC_COL           EQU 0E000H      
MASCARA           EQU 0FH       
MAX_CONT   	      EQU 999

DEFINE_LINHA      EQU 600AH
DEFINE_COLUNA     EQU 600CH
DEFINE_PIXEL      EQU 6012H

;--------MediaCenter---------
CENARIO_FUNDO     EQU 6042H
PLAY_MEDIA        EQU 6000H + 5AH

;----Constantes do peixe----
LINHA_CENTRO      EQU 14
COLUNA_CENTRO     EQU 30

LARGURA_PEIXE     EQU 5
ALTURA_PEIXE      EQU 3

;----Constantes da boia------
LINHA_BOIA_1      EQU 8
COLUNA_BOIA_1     EQU 48

LINHA_BOIA_2      EQU 2
COLUNA_BOIA_2     EQU 3

LINHA_BOIA_3      EQU 21
COLUNA_BOIA_3     EQU 55

LINHA_BOIA_4      EQU 2
COLUNA_BOIA_4     EQU 28

DIMENSAO_BOIA     EQU 4

;----Constantes do disparo------
DIMENSAO_DISPARO  EQU 1

ALCANCE_NORMAL    EQU 10
ALCANCE_REFORCADO EQU 20

;----Constantes da explosão------
DIMENSAO_EXPLOSAO EQU 3

;----Constantes do prémio------
LINHA_PREMIO      EQU 22
COLUNA_PREMIO     EQU 3

DIMENSAO_PREMIO   EQU 4

;----Constantes da zona proibida------
LINHA_ZP_1        EQU 11
COLUNA_ZP_1       EQU 16

LINHA_ZP_2        EQU 7
COLUNA_ZP_2       EQU 38

LINHA_ZP_3        EQU 20
COLUNA_ZP_3       EQU 9

LINHA_ZP_4        EQU 19
COLUNA_ZP_4       EQU 43

DIMENSAO_ZP_1     EQU 6
DIMENSAO_ZP_2     EQU 3
DIMENSAO_ZP_3     EQU 5

;--------------CORES---------------
CINZA_CL       EQU 0F999H 
CINZA          EQU 0F777H
CINZA_ESC      EQU 0F555H 
AZUL           EQU 0F005H
VERDE_CL       EQU 0F070H
VERDE          EQU 0F050H
LARANJA        EQU 0FD60H
VERMELHO       EQU 0FF00H
BRANCO   	   EQU 0FFFFH
PRETO          EQU 0F000H

; ------------------------------------------------
; ******************* DADOS **********************
; ------------------------------------------------

;------------------PILHA------------------
PLACE 1000H
pilha: STACK 100H
SP_inicial  EQU 1200H

;-----------VARIÁVEIS DO PROGRAMA---------
PLACE 1200H    
   
;INTERRUPÇÕES
tab:
    WORD rotina_int0     ; INT0 – movimentação das boias
    WORD rotina_int1     ; INT1 – relógio do tempo de jogo
    WORD rotina_int2     ; INT2 – apagar explosão
    WORD rotina_int3     ; INT3 – movimento da bala (disparo)

;CONTROLO GERAL
contador: WORD 0                 ; Contador de tempo
tempo_ativo: WORD 0              ; 0 = parado | 1 = a contar
terminou_jogo: WORD 0            ; 1 = jogo terminou
reiniciar_jogo: WORD 0           ; 1 = sinal para reiniciar
atualizar_display_tempo: WORD 0  ; 1 = atualizar mostrador tempo
mostrar_imagem_fim_flag: WORD 0  ; 1 = mostrar imagem final
apagar_tudo_flag: WORD 0         ; 1 = sinal para limpar ecrã
executar_tecla_flag: WORD 0      ; 1 = sinal para executar tecla
em_pausa: WORD 0                 ; 1 = jogo em pausa

;PEIXE
linha_peixe: WORD LINHA_CENTRO
coluna_peixe: WORD COLUNA_CENTRO
direcao_peixe: WORD 0  ; 0 = direita | 1 = esquerda

;BOIAS
mover_bolas_flag: WORD 0   ; 1 = mover boias
linha_boia_1: WORD LINHA_BOIA_1
coluna_boia_1: WORD COLUNA_BOIA_1
linha_boia_2: WORD LINHA_BOIA_2
coluna_boia_2: WORD COLUNA_BOIA_2
linha_boia_3: WORD LINHA_BOIA_3
coluna_boia_3: WORD COLUNA_BOIA_3
linha_boia_4: WORD LINHA_BOIA_4
coluna_boia_4: WORD COLUNA_BOIA_4

;DISPARO 
linha_bala: WORD 0
coluna_bala: WORD 0
bala_ativa: WORD 0       ; 1 = bala ativa
direcao_bala: WORD 0    ; 0 = esquerda | 1 = direita
alcance_bala: WORD ALCANCE_NORMAL
tiros_reforcados: WORD 0
tiros_usados: WORD 0
passos_bala: WORD 0    ; pixeis percorridos pelo disparo
mover_bala_flag: WORD 0       ; 1 = mover bala

;PRÉMIO 
linha_premio: WORD LINHA_PREMIO
coluna_premio: WORD COLUNA_PREMIO
visivel_premio: WORD 1   ; 1 = visível | 0 = invisível

;EXPLOSÃO
explosao_ativa: WORD 0    ; 1 = explosão ativa
linha_explosao: WORD 0
coluna_explosao: WORD 0
apagar_explosao_flag: WORD 0  ; 1 = apagar explosão

;TEMPO DE JOGO
tempo_jogo: WORD 0    ; tempo total de jogo
tecla_anterior: WORD 0FFF8H    ; tecla inicialmente inexistente
tempo_tecla: WORD 0      ; temporizador de tecla para repetição automática

;BACKUP (PAUSA)
linha_peixe_backup: WORD 0
coluna_peixe_backup: WORD 0
direcao_peixe_backup: WORD 0

linha_boia_1_backup: WORD 0
coluna_boia_1_backup: WORD 0
linha_boia_2_backup: WORD 0
coluna_boia_2_backup: WORD 0
linha_boia_3_backup: WORD 0
coluna_boia_3_backup: WORD 0
linha_boia_4_backup: WORD 0
coluna_boia_4_backup: WORD 0

linha_premio_backup: WORD 0
coluna_premio_backup: WORD 0
visivel_premio_backup: WORD 0

contador_backup: WORD 0      


;------------TABELAS DE PIXEIS------------
PLACE 1300H
DEF_PEIXE_DIR:
	WORD LARGURA_PEIXE
	WORD ALTURA_PEIXE
	;tabela de cores
	WORD LARANJA,0,LARANJA,LARANJA,LARANJA
	WORD 0,LARANJA,LARANJA,LARANJA,PRETO
	WORD LARANJA,0,LARANJA,LARANJA,LARANJA

DEF_PEIXE_ESQ:
	WORD LARGURA_PEIXE
	WORD ALTURA_PEIXE
	;tabela de cores
	WORD LARANJA,LARANJA,LARANJA,0,LARANJA
	WORD PRETO,LARANJA,LARANJA,LARANJA,0
	WORD LARANJA,LARANJA,LARANJA,0,LARANJA
	
DEF_BOIA:
	WORD DIMENSAO_BOIA
	WORD DIMENSAO_BOIA
	;tabela de cores
	WORD 0,VERMELHO,BRANCO,0
	WORD BRANCO,0,0,VERMELHO
	WORD VERMELHO,0,0,BRANCO
	WORD 0,BRANCO,VERMELHO,0

DEF_DISPARO:
	WORD DIMENSAO_DISPARO
	WORD DIMENSAO_DISPARO
	;tabela de cores
	WORD AZUL

DEF_EXPLOSAO:
	WORD DIMENSAO_EXPLOSAO
	WORD DIMENSAO_EXPLOSAO
	;tabela de cores
	WORD BRANCO,0,BRANCO
	WORD 0,BRANCO,0
	WORD BRANCO,0,BRANCO

DEF_PREMIO:
	WORD DIMENSAO_PREMIO
	WORD DIMENSAO_PREMIO
	;tabela de cores
	WORD 0,0,VERDE_CL,VERDE
	WORD 0,VERDE_CL,VERDE,VERDE
	WORD 0,VERDE,VERDE,0
	WORD VERDE_CL,0,0,0
	
DEF_ZP_1:
	WORD DIMENSAO_ZP_1
	WORD DIMENSAO_ZP_2
	;tabela de cores
	WORD CINZA_CL,CINZA_CL,CINZA_CL,CINZA_CL,CINZA_CL,CINZA_CL
	WORD CINZA_CL,CINZA,CINZA,CINZA,CINZA,CINZA_ESC
	WORD CINZA_ESC,CINZA_ESC,CINZA_ESC,CINZA_ESC,CINZA_ESC,CINZA_ESC
	
DEF_ZP_2:
	WORD DIMENSAO_ZP_2
	WORD DIMENSAO_ZP_1
	;tabela de cores
	WORD CINZA_CL,CINZA_CL,CINZA_CL
	WORD CINZA_CL,CINZA,CINZA_ESC
	WORD CINZA_CL,CINZA,CINZA_ESC
	WORD CINZA_CL,CINZA,CINZA_ESC
	WORD CINZA_CL,CINZA,CINZA_ESC
	WORD CINZA_ESC,CINZA_ESC,CINZA_ESC
	
DEF_ZP_3:
	WORD DIMENSAO_ZP_3
	WORD DIMENSAO_ZP_3
	;tabela de cores
	WORD CINZA_CL,CINZA_CL,CINZA_CL,CINZA_CL,CINZA_CL
	WORD CINZA_CL,CINZA,CINZA,CINZA,CINZA_ESC
	WORD CINZA_CL,CINZA,CINZA,CINZA,CINZA_ESC
	WORD CINZA_CL,CINZA,CINZA,CINZA,CINZA_ESC
	WORD CINZA_ESC,CINZA_ESC,CINZA_ESC,CINZA_ESC,CINZA_ESC
	
DEF_ZP_4:
	WORD DIMENSAO_ZP_3
	WORD DIMENSAO_ZP_3
	;tabela de cores
	WORD CINZA_CL,CINZA_CL,CINZA_CL,CINZA_CL,CINZA_CL
	WORD CINZA_CL,CINZA,CINZA,CINZA,CINZA_ESC
	WORD CINZA_CL,CINZA,CINZA,CINZA,CINZA_ESC
	WORD CINZA_CL,CINZA,CINZA,CINZA,CINZA_ESC
	WORD CINZA_ESC,CINZA_ESC,CINZA_ESC,CINZA_ESC,CINZA_ESC
	

	

; ------------------------------------------------------------
; ************************* Código ***************************
; ------------------------------------------------------------
PLACE 0

inicio:
	MOV SP, SP_inicial
	MOV BTE, tab   ;base da tabela de exceções
	EI0
	EI1
	EI2
	EI3
	EI
comecar:
	MOV R0, 1         
	CALL mostra_imagem_fundo
	CALL desenha_moldura
	
espera_tecla_c:
    MOV R2, TEC_LIN  ; Define registo das linhas do teclado
    MOV R3, TEC_COL  ; Define registo das colunas do teclado
    MOV R5, MASCARA  ; Máscara para isolar bits relevantes das colunas

    MOV R1, 1      ; Começa na primeira linha (bit 0 ativo)
procura_c:
    MOVB [R2], R1   ; Ativa uma linha de cada vez
    MOVB R0, [R3]   ; Lê as colunas (bit ativo indica tecla premida)
    AND R0, R5      ; Isola apenas os bits úteis
    CMP R0, 0
    JNZ tecla_c_foi_premida

    SHL R1, 1    ; Passa para a próxima linha (desloca bit ativo)
	MOV R6, 10H  ; Limite superior das linhas (após 4ª linha)
    CMP R1, R6
    JNZ procura_c
    JMP espera_tecla_c

tecla_c_foi_premida:
    ; Converter R1 e R0 para valor da tecla
    MOV R9, R0
    CALL converte_indice
    MOV R10, R0
    MOV R1, R9
    CALL converte_indice
    MOV R7, R0
    MOV R0, R10
    SHL R0, 2    ; R0 = linha * 4
    ADD R0, R7   ; R0 = índice total da tecla (linha*4 + coluna)

    ; Verifica se é a tecla 'C' (valor 0CH)
    MOV R6, 0CH
    CMP R0, R6
    JNZ espera_tecla_c
	MOV R0, 0       
	CALL toca_som
	CALL reset_variaveis
	CALL comeca_jogo

; Leitura do teclado
teclado:
    MOV R2, TEC_LIN       
    MOV R3, TEC_COL       
    MOV R4, DISPLAYS     
    MOV R5, MASCARA     

loop_teclado:
	 ; Verifica se deve apagar tudo
    MOV R0, [apagar_tudo_flag]
    CMP R0, 1
    JNZ ignora_fimm

    CALL apaga_todos_os_objetos
    MOV R0, 0
    MOV [apagar_tudo_flag], R0

ignora_fimm:
    ; Verifica se deve mostrar imagem de fim
    MOV R0, [mostrar_imagem_fim_flag]
    CMP R0, 1
    JNZ continua_loop_teclado

    MOV R0, 3
    CALL toca_som
    MOV R0, 5         
    CALL mostra_imagem_fundo
    MOV R0, 0
    MOV [mostrar_imagem_fim_flag], R0

continua_loop_teclado:
    ; Verifica se o jogo está em pausa
    MOV R6, [em_pausa]
    CMP R6, 1
    JZ continuar_procura  ; ignora movimento se em pausa
	
	;Verifcação de flags
    MOV R6, [mover_bala_flag]
    CMP R6, 1
    JNZ verifica_bolas
    MOV R6, 0
    MOV [mover_bala_flag], R6
    CALL mover_bala
	MOV R6, [terminou_jogo]
	CMP R6, 1
	JZ espera_tecla_c
	MOV R6, [reiniciar_jogo]
	CMP R6, 1
	JZ comecar

verifica_bolas:
    ; Verifica se houve interrupção para mover as bolas
    MOV R6, [mover_bolas_flag]
    CMP R6, 1
    JNZ continuar_procura

    MOV R6, 0
    MOV [mover_bolas_flag], R6
    CALL mover_todas_bolas
    
	CALL verifica_colisao_peixe_boia
	
    ; Se estiver em pausa, ignora atualização do tempo
    MOV R6, [em_pausa]
    CMP R6, 1
    JZ ignora_update

    ; Verifica se precisa atualizar o display do tempo
    MOV R0, [atualizar_display_tempo]
    CMP R0, 1
    JNZ ignora_update

    CALL mostra_tempo_jogo
    MOV R0, 0
    MOV [atualizar_display_tempo], R0

ignora_update:
    ; Se explosão está ativa, precisa ser apagada
    MOV R0, [apagar_explosao_flag]
    CMP R0, 1
    JNZ ignora_apaga

    PUSH R2
    MOV R0, DEF_EXPLOSAO
    MOV R1, [linha_explosao]
    MOV R2, [coluna_explosao]
    CALL apaga_objeto
    POP R2
    MOV R0, 0
    MOV [apagar_explosao_flag], R0
    MOV [explosao_ativa], R0

ignora_apaga:
    ; Verifica se deve apagar tudo
    MOV R0, [apagar_tudo_flag]
    CMP R0, 1
    JNZ ignora_fim

    CALL apaga_todos_os_objetos
    MOV R0, 0
    MOV [apagar_tudo_flag], R0

ignora_fim:
    ; Verifica se deve mostrar imagem de fim
    MOV R0, [mostrar_imagem_fim_flag]
    CMP R0, 1
    JNZ continuar_procura

    MOV R0, 3
    CALL toca_som
    MOV R0, 5          ; Número da imagem de fim de tempo
    CALL mostra_imagem_fundo
    MOV R0, 0
    MOV [mostrar_imagem_fim_flag], R0

continuar_procura:
    MOV R1, 1             ; Começa pela linha 0001b

procura_tecla:
    MOVB [R2], R1         
    MOVB R0, [R3]         ; Lê as colunas (bits ativos = tecla premida)  
    AND R0, R5            ; Ignora bits irrelevantes
    CMP R0, 0             ; Verifica se há uma tecla premida 
    JNZ ha_tecla

    SHL R1, 1             ; Passa para a linha seguinte
    MOV R6, 10H
    CMP R1, R6
    JNZ procura_tecla

    ; Reinicia a tecla anterior registada
    MOV R6, 0FFF8H         
    MOV [tecla_anterior], R6

    JMP loop_teclado

;Verifica qual a tecla premida 
ha_tecla:
	MOV R9, R0            ; Guarda coluna
    ; converte linha para índice 0-3
    CALL converte_indice
    MOV R10, R0       
    ; converte coluna para índice 0-3
	MOV R1, R9
    CALL converte_indice
    MOV R7, R0      
    ; valor da tecla = 4 * linha + coluna
    MOV R0, R10
    SHL R0, 2
    ADD R0, R7            ; Valor real da tecla guardado em R0


;Verifica se alguma tecla está a ser premida
	CALL verifica_teclas
	; Verifica se é preciso executar a tecla (por flag da interrupção)
    MOV R6, [executar_tecla_flag]
    CMP R6, 1
    JNZ continua_teclado
    MOV R6, 0
    MOV [executar_tecla_flag], R6
    CALL executar_tecla

continua_teclado:
	
    JMP teclado


; ----------------------------------------------------------	
; *********************** ROTINAS **************************
; ----------------------------------------------------------

; ---------------------COMEÇA JOGO-----------------------------
; Inicia o jogo propriamente dito após o ecrã inicial
; INPUT: as variáveis globais de posição devem já estar inicializadas 
; OUTPUT: todos os elementos do jogo desenhados no ecrã.
; REGISTOS:
;   R0 – usado para carregar a tabela de pixeis de cada objeto
;   R1 – linha onde desenhar
;   R2 – coluna onde desenhar

comeca_jogo:
	PUSH R0
	PUSH R1
	PUSH R2

	MOV R0,0
	MOV [terminou_jogo], R0
	MOV [reiniciar_jogo], R0
	CALL mostra_imagem_fundo
	;desenha o peixe na posição central do ecrã
	MOV R0, DEF_PEIXE_DIR  
	MOV R1, LINHA_CENTRO         
	MOV R2, COLUNA_CENTRO  
	CALL desenha_objeto
	;desenha a bóia 1 numa posição fixa
	MOV R0, DEF_BOIA
	MOV R1, LINHA_BOIA_1
	MOV R2, COLUNA_BOIA_1
	CALL desenha_objeto
	;desenha a bóia 2 numa posição fixa
	MOV R0,DEF_BOIA
	MOV R1,LINHA_BOIA_2
	MOV R2,COLUNA_BOIA_2
	CALL desenha_objeto
	;desenha a bóia 3 numa posição fixa
	MOV R0,DEF_BOIA
	MOV R1,LINHA_BOIA_3
	MOV R2,COLUNA_BOIA_3
	CALL desenha_objeto
	;desenha a bóia 4 numa posição fixa
	MOV R0,DEF_BOIA
	MOV R1,LINHA_BOIA_4
	MOV R2,COLUNA_BOIA_4
	CALL desenha_objeto
	;desenha a zona proibida 1 numa posição fixa
	MOV R0,DEF_ZP_1
	MOV R1,LINHA_ZP_1
	MOV R2,COLUNA_ZP_1
	CALL desenha_objeto
	;desenha a zona proibida 2 numa posição fixa
	MOV R0,DEF_ZP_2
	MOV R1,LINHA_ZP_2
	MOV R2,COLUNA_ZP_2
	CALL desenha_objeto
	;desenha a zona proibida 3 numa posição fixa
	MOV R0,DEF_ZP_3
	MOV R1,LINHA_ZP_3
	MOV R2,COLUNA_ZP_3
	CALL desenha_objeto
	;desenha a zona proibida 4 numa posição fixa
	MOV R0,DEF_ZP_4
	MOV R1,LINHA_ZP_4
	MOV R2,COLUNA_ZP_4
	CALL desenha_objeto
	;desenha o premio numa posição fixa
	MOV R0,DEF_PREMIO
	MOV R1,LINHA_PREMIO
	MOV R2,COLUNA_PREMIO
	CALL desenha_objeto
	;desenha moldura à volta
	;CALL desenha_moldura
	MOV R0, 1
	MOV [tempo_ativo], R0
	
	POP R2
	POP R1
	POP R0
	RET
;-------------------- MOSTRA IMAGEM FUNDO------------------
; Mostra a imagem corresponde ao valor recebido
; INPUT:
; 	R0 - valor da imagem a mostrar 
; OUTPUT: aparece a imagem esperada

mostra_imagem_fundo:
    PUSH R6
    MOV R6, R0
    MOV [CENARIO_FUNDO], R6
    POP R6
    RET

;------------------TOCA SOM-------------------------
; Toca o som corresponde ao valor recebido
; INPUT:
; 	R0 - valor do som a tocar 
; OUTPUT: sai o som esperado

toca_som:
    PUSH R6
    MOV R6, R0
    MOV [PLAY_MEDIA], R6
    POP R6
    RET

;--------------------DESENHA MOLDURA---------------------
; Esta rotina desenha uma moldura à volta do ecrã do jogo
; INPUT: nenhum valor externo é necessário diretamente (usa constantes internas)
; OUTPUT: Moldura do jogo desenhada nas bordas do ecrã

desenha_moldura:
    PUSH R1
    PUSH R2
	PUSH R6
	PUSH R7
	
	MOV R7, AZUL 
	
;Primeira linha ( linha = 0 )
linha_topo:

	MOV R1, 0
    MOV R2, 0          
topo_loop:
	;percorre todas as colunas da primeira linha
	MOV R6, 64
    CMP R2, R6                 
    JGE linha_fundo
    MOV [DEFINE_LINHA], R1
    MOV [DEFINE_COLUNA], R2
    MOV [DEFINE_PIXEL], R7     ; Coloca a cor nesse pixel
    ADD R2, 1                  ; Passa para a próxima coluna
    JMP topo_loop

;Última linha ( linha = 31 )
linha_fundo:
	MOV R1, 31
    MOV R2, 0
fundo_loop:
	;percorre todas as colunas da última linha
	MOV R6, 64
    CMP R2, R6
    JGE coluna_esquerda
    MOV [DEFINE_LINHA], R1
    MOV [DEFINE_COLUNA], R2
    MOV [DEFINE_PIXEL], R7      ; Coloca a cor nesse pixel
    ADD R2, 1					; Passa para a próxima coluna
    JMP fundo_loop

;Primeira coluna ( coluna = 0 )
coluna_esquerda:
    MOV R1, 1
	MOV R2, 0
esquerda_loop:
	;percorre todas as linhas da primeira coluna
	MOV R6, 32
    CMP R1, R6
    JGE coluna_direita
    MOV [DEFINE_LINHA], R1
    MOV [DEFINE_COLUNA], R2
    MOV [DEFINE_PIXEL], R7		; Coloca a cor nesse pixel
    ADD R1, 1					; Passa para a próxima linha
    JMP esquerda_loop

;Última coluna ( coluna 63 )
coluna_direita:
    MOV R1, 1
	MOV R2, 63
direita_loop:
	;percorre todas as linhas da última coluna
	MOV R6, 32
    CMP R1, R6
    JGE fim_moldura
    MOV [DEFINE_LINHA], R1
    MOV [DEFINE_COLUNA], R2		
    MOV [DEFINE_PIXEL], R7		; Coloca a cor nesse pixel
    ADD R1, 1					; Passa para a próxima linha
    JMP direita_loop

fim_moldura:
	POP R7
	POP R6
    POP R2
    POP R1
    RET
	
;-------------------VERIFICA TECLAS---------------------
; Verifica a tecla premida e executa a ação correspondente, desde
; disparo, pausa, reinício, até guardar a tecla premida
; INPUT:
;   R0 – valor da tecla premida
;   [tecla_anterior] – tecla anteriormente registada
;   [em_pausa], [tempo_ativo] – estado do jogo
; OUTPUT:
;   Atualização das variáveis de jogo
;   [tecla_anterior] atualizada
;   [tempo_tecla] reiniciado

verifica_teclas:
    ; Verifica se foi premida a tecla 'E' (valor 0EH) - termina o jogo e reinicia
    MOV R7, 0EH
    CMP R0, R7
    JNZ verifica_tecla_3
    MOV R6, [tecla_anterior]
    CMP R0, R6
    JZ guarda_tecla
	; Reinicia o jogo
	MOV R6,1
    MOV [reiniciar_jogo],R6
	CALL apaga_todos_os_objetos
	MOV R6,0
	MOV [tempo_ativo],R6
	JMP guarda_tecla

verifica_tecla_3:
    ; Verifica se '3' foi premida (disparo para a esquerda)
    MOV R7, 3
    CMP R0, R7
    JNZ verifica_tecla_7
    MOV R6, [tecla_anterior]
    CMP R0, R6
    JZ guarda_tecla
    CALL disparar_esq
    JMP guarda_tecla

verifica_tecla_7:
    ; Verifica se '7' foi premida (disparo para a direita)
    MOV R7, 7
    CMP R0, R7
    JNZ verifica_tecla_d
    MOV R6, [tecla_anterior]
    CMP R0, R6
    JZ guarda_tecla
    CALL disparar_dir
    JMP guarda_tecla

verifica_tecla_d:
    ; Verifica se 'D' foi premida (toggle pausa)
    MOV R7, 0DH
    CMP R0, R7
    JNZ verifica_estado_pausa
    MOV R6, [tecla_anterior]
    CMP R0, R6
    JZ guarda_tecla
    CALL atrasar

    ; Lê estado atual da pausa
    MOV R6, [em_pausa]
    CMP R6, 0
    JZ entra_pausa

sai_pausa:
	;Retoma jogo
    MOV R6, 0
    MOV [em_pausa], R6
    MOV R0, 1
    MOV [tempo_ativo], R0

    CALL apaga_todos_os_objetos

    ; Restaurar estado
    CALL restaurar_estado_jogo
	MOV R0,0
	CALL mostra_imagem_fundo
	MOV R0,0
	CALL toca_som

    ; Desenhar tudo nas posições guardadas
    CALL desenha_estado_jogo

    JMP fim_verifica_teclas

entra_pausa:
    MOV R6, 1
    MOV [em_pausa], R6
    MOV R0, 0
    MOV [tempo_ativo], R0

    ; Guardar estado atual
    CALL guardar_estado_jogo

    ; Apagar tudo do ecrã
    CALL apaga_todos_os_objetos

    ; Mostrar imagem de pausa 
    MOV R0, 4
    CALL mostra_imagem_fundo

    JMP fim_verifica_teclas

verifica_estado_pausa:
    ; Só executa a tecla se não estiver em pausa
    MOV R6, [em_pausa]
    CMP R6, 1
    JZ fim_verifica_teclas

    CALL executar_tecla

guarda_tecla:
	;Atualiza a tecla atual e reinicia o tempo da tecla
    MOV [tecla_anterior], R0
    MOV R7, 0
    MOV [tempo_tecla], R7

fim_verifica_teclas:
    RET



;-------------------VERIFICA TECLAS---------------------
; Executa a ação associada à tecla armazenada
; INPUT: 
; 	R0 - tecla anterior
;   R3 - indica a mover_peixe_e e mover_peixe_d a direção consoante a tecla
; OUTPUT: Cada tecla desempenha a sua função corresponde

executar_tecla:
	PUSH R0
    PUSH R3

    MOV R0, [tecla_anterior]

    ; Se nenhuma tecla está ativa, sai
    CMP R0, 0FFF8H
    JZ fim_exec
    ; Verifica tecla 0
    CMP R0, 0
    JNZ tecla_1
    MOV R3, 4
	CALL atrasar
    CALL mover_peixe_e
    JMP fim_exec

tecla_1:
    CMP R0, 1
    JNZ tecla_2
    MOV R3, 1
	CALL atrasar
    CALL mover_peixe_d
    JMP fim_exec

tecla_2:
    CMP R0, 2
    JNZ tecla_4
    MOV R3, 2
	CALL atrasar
    CALL mover_peixe_d
    JMP fim_exec

tecla_4:
    CMP R0, 4
    JNZ tecla_6
    MOV R3, 3
	CALL atrasar
    CALL mover_peixe_e
    JMP fim_exec

tecla_6:
    CMP R0, 6
    JNZ tecla_8
    MOV R3, 3
	CALL atrasar
    CALL mover_peixe_d
    JMP fim_exec

tecla_8:
	MOV R7,8
    CMP R0, R7
    JNZ tecla_9
    MOV R3, 2
	CALL atrasar
    CALL mover_peixe_e
    JMP fim_exec

tecla_9:
	MOV R7, 9
    CMP R0, R7
    JNZ tecla_a
    MOV R3, 1
	CALL atrasar
    CALL mover_peixe_e
    JMP fim_exec

tecla_a:
	MOV R7, 0AH
    CMP R0, R7
    JNZ fim_exec
    MOV R3, 4
	CALL atrasar
    CALL mover_peixe_d
	
fim_exec:
    POP R3
    POP R0
    RET

;------------------DISPARAR PARA A DIREITA------------------
; Ativa um disparo na direção esquerda, se não houver já um ativo.
; Define a posição inicial da bala baseada na posição atual do peixe.
; INPUT: 
; 	R1 - linha_peixe
; 	R2 - coluna peixe
; OUTPUT:
; 	[linha_bala], [coluna_bala] – posição inicial da bala
;   Flag direcao_bala = 1 (esquerda)
;   Flag bala_ativa = 1 (ativa)
;   [alcance_bala] – definido conforme tipo de tiro
;   Toca som consoante alcance do disparo
; Registos:
; R0/R6 - valor temporário
disparar_esq:
    PUSH R0
    PUSH R1
    PUSH R2
    PUSH R6

    ; Verifica se já existe uma bala ativa
    MOV R6, [bala_ativa]
    CMP R6, 1
    JZ fim_disparar_esq  ; já há bala em movimento

    ; Ativa a flag
    MOV R6, 1
    MOV [bala_ativa], R6
	
	; TOCA SOM DE DISPARO
	MOV R0, 1
	CALL toca_som

    ; Guarda direção
    MOV R6, 0
    MOV [direcao_bala], R6

    ; Define alcance
    MOV R6, [tiros_reforcados]
    CMP R6, 0
    JZ alcance_normal_esq
	MOV R0,6
	CALL toca_som   ; som diferente enquanto tiros têm alcance reforçado
    MOV R6, ALCANCE_REFORCADO
    MOV [alcance_bala], R6
    MOV R6, [tiros_reforcados]
    SUB R6, 1
    MOV [tiros_reforcados], R6
    JMP definir_posicao_esq

alcance_normal_esq:
    MOV R6, ALCANCE_NORMAL
    MOV [alcance_bala], R6

definir_posicao_esq:
    ; Desenha peixe virado para a esquerda 
    MOV R0, DEF_PEIXE_ESQ
    MOV R1, [linha_peixe]
    MOV R2, [coluna_peixe]
    CALL desenha_objeto

    ; Linha da bala = centro vertical do peixe
    MOV R1, [linha_peixe]
    ADD R1, 1
    MOV [linha_bala], R1

    ; Coluna da bala = à direita do peixe
    MOV R2, [coluna_peixe]
    SUB R2, 1
    MOV [coluna_bala], R2

    ; Desenha a bala
    MOV R0, DEF_DISPARO
	CALL atrasar
    CALL desenha_objeto

fim_disparar_esq:
    POP R6
    POP R2
    POP R1
    POP R0
    RET
	
;------------------DISPARAR PARA A DIREITA------------------
; Ativa um disparo na direção direita, se não houver já um ativo.
; Define a posição inicial da bala baseada na posição atual do peixe.
; INPUT: 
; 	R1 - linha_peixe
; 	R2 - coluna peixe
; OUTPUT:
; 	[linha_bala], [coluna_bala] – posição inicial da bala
;   Flag direcao_bala = 1 (direita)
;   Flag bala_ativa = 1 (ativa)
;   [alcance_bala] – definido conforme tipo de tiro
;   Toca som consoante alcance do disparo
; Registos:
; R0/R6 - valor temporário

disparar_dir:
    PUSH R0
    PUSH R1
    PUSH R2
    PUSH R6

    ; Verifica se já existe uma bala ativa
    MOV R6, [bala_ativa]
    CMP R6, 1
    JZ fim_disparar_dir   ; já há bala em movimento

    ; Ativa a flag
    MOV R6, 1
    MOV [bala_ativa], R6

	MOV R0, 1
	CALL toca_som
	
    ; Guarda direção
    MOV R6, 1
    MOV [direcao_bala], R6

    ; Define alcance conforme tiros reforçados
    MOV R6, [tiros_reforcados]
    CMP R6, 0
    JZ alcance_normal_dir
	MOV R0,6
	CALL toca_som  ; som diferente enquanto tiros têm alcance reforçado
    MOV R6, ALCANCE_REFORCADO
    MOV [alcance_bala], R6
    MOV R6, [tiros_reforcados]
    SUB R6, 1
    MOV [tiros_reforcados], R6
    JMP definir_posicao_dir

alcance_normal_dir:
    MOV R6, ALCANCE_NORMAL
    MOV [alcance_bala], R6

definir_posicao_dir:
    ; Redesenha o peixe virado para a direita
    MOV R0, DEF_PEIXE_DIR
    MOV R1, [linha_peixe]
    MOV R2, [coluna_peixe]
    CALL desenha_objeto

    ; Linha da bala = centro vertical do peixe
    MOV R1, [linha_peixe]
    ADD R1, 1
    MOV [linha_bala], R1

    ; Coluna da bala = à direita do peixe
    MOV R2, [coluna_peixe]
    ADD R2, LARGURA_PEIXE
    MOV [coluna_bala], R2

    ; Desenha a bala
    MOV R0, DEF_DISPARO
    CALL desenha_objeto

fim_disparar_dir:
    POP R6
    POP R2
    POP R1
    POP R0
    RET

;------------------MOVER BALA------------------
; Move a bala uma posição na direção correta e apaga-a quando atingir o alcance
; INPUT:
;	R1 - linha atual da bala
;	R2 - coluna atual da bala
;   R7 - alcance total da bala
; OUTPUT: 
;   Toca som quando bala toca na parede (7)
;   Atualiza a posição da bala em [linha_bala], [coluna_bala]
;   Apaga bala se sair dos limites ou atingir zona proibida
;   Chama explosão se atingir boia ou prémio
;Registos:
; 	R6/R8/R9 - valores teemporários

mover_bala:
    PUSH R0
    PUSH R1
    PUSH R2
    PUSH R6
    PUSH R7
	PUSH R8
	PUSH R9
	
    ; Verifica se há bala ativa
    MOV R6, [bala_ativa]
    CMP R6, 0
    JZ fim_mover_bala

    ; Apaga a bala na posição atual
    MOV R0, DEF_DISPARO
    MOV R1, [linha_bala]
    MOV R2, [coluna_bala]
    CALL apaga_objeto

    ; Atualiza posição conforme a direção
    MOV R1, [linha_bala]
    MOV R2, [coluna_bala]
    MOV R6, [direcao_bala]
    CMP R6, 1
    JZ mover_direita

mover_esquerda:
    SUB R2, 1
    JMP continuar_movimento

mover_direita:
    ADD R2, 1

continuar_movimento:
    ; Atualiza linha/coluna
    MOV [linha_bala], R1
    MOV [coluna_bala], R2

    ; Incrementa passos dados até ao momento
    MOV R6, [passos_bala]
    ADD R6, 1
    MOV [passos_bala], R6

    ; Verifica se atingiu o alcance
    MOV R7, [alcance_bala]
    CMP R6, R7
    JGE apagar_bala

    ; Verifica se está fora dos limites do ecrã
    CMP R2, 1
    JLT bateu_na_parede
	MOV R6,62
    CMP R2, R6
    JGT bateu_na_parede
	
	; Verifica se bala colide com zona proibida
	MOV R1, [linha_bala]
	MOV R2, [coluna_bala]
	MOV R8, 1
	MOV R9, 1
	CALL colisao_com_zona_proibida
	CMP R0, 1
	JZ bateu_na_parede
	
    ; Desenha na nova posição
    MOV R0, DEF_DISPARO
    CALL desenha_objeto
    CALL verifica_colisao_boia_disparo
	JMP fim_mover_bala
	
bateu_na_parede:
	MOV R0,7
	CALL toca_som

apagar_bala:
    ; Desativa a bala
    MOV R6, 0
    MOV [bala_ativa], R6
    MOV [passos_bala], R6   ; reset também
    ; Não redesenha nada

fim_mover_bala:
	POP R9
	POP R8
    POP R7
    POP R6
    POP R2
    POP R1
    POP R0
    RET

;------------------VERIFICA COLISÃO COM ZONA PROIBIDA--------------------
; Inicializa valores e verifica se houve colisão com ZP
; INPUT:
; 	R3 - LINHA_ZP_X (X=1 a 4)
; 	R4 - COLUNA_ZP_X (X=1 a 4)
; 	R5/R6 - DIMENSAO_ZP_X (X=1 a 4)
; OUTPUT:
; 	R0 = 0 - houve Colisão
; 	R0 =1 - não houve colisão

colisao_com_zona_proibida:
    PUSH R3
    PUSH R4
    PUSH R5
    PUSH R6

    MOV R0, 0
    ;inicializa a localização e dimenção de ZP_1
    MOV R3, LINHA_ZP_1      
    MOV R4, COLUNA_ZP_1    
    MOV R5, DIMENSAO_ZP_2  
    MOV R6, DIMENSAO_ZP_1   
    CALL testa_colisao		; Vai testar se há colisão
    CMP R0, 1
    JZ fim_colisao

    ;inicializa a localização e dimenção de ZP_2
    MOV R3, LINHA_ZP_2
    MOV R4, COLUNA_ZP_2
    MOV R5, DIMENSAO_ZP_1
    MOV R6, DIMENSAO_ZP_2
    CALL testa_colisao		; Vai testar se há colisão
    CMP R0, 1
    JZ fim_colisao

    ;inicializa a localização e dimenção de ZP_3
    MOV R3, LINHA_ZP_3
    MOV R4, COLUNA_ZP_3
    MOV R5, DIMENSAO_ZP_3
    MOV R6, DIMENSAO_ZP_3
    CALL testa_colisao		; Vai testar se há colisão
    CMP R0, 1
    JZ fim_colisao

    ;inicializa a localização e dimenção de ZP_3
    MOV R3, LINHA_ZP_4
    MOV R4, COLUNA_ZP_4
    MOV R5, DIMENSAO_ZP_3
    MOV R6, DIMENSAO_ZP_3
    CALL testa_colisao		; Vai testar se há colisão
    CMP R0, 1

fim_colisao:
    POP R6
    POP R5
    POP R4
    POP R3
    RET

;------------------VERIFICA COLISAO COM PREMIO------------------
; Verifica se o peixe colidiu com o prémio (se visível).
; Usa testa_colisao com ALTURA_PEIXE e LARGURA_PEIXE via R8/R9
; INPUT:
; 	R1/R2 - posição do peixe
;   R3/R4 - posição do prémio
;   R5/R6 - dimensão do prémio
;   R8/R9 - dimensão do peixe
; OUTPUT: Quando há colisão:
; 	Flag visivel_premio = 0 (premio desaparece)
;   [linha_premio] = 32 (fora do ecrã)
;   [tiros_reforcados] = 10
;   [alcance_bala] = ALCANCE_REFORCADO
;   Toca o som (5)
; Registo:
; 	R0 - valor temporário

verifica_colisao_premio:
    PUSH R0
    PUSH R1
    PUSH R2
    PUSH R3
    PUSH R4
    PUSH R5
    PUSH R6
    PUSH R8
    PUSH R9

	;Verifica se o prémio está visível
    MOV R6, [visivel_premio]
    CMP R6, 1
    JNZ fim_verifica_premio

	;Define dimensões do peixe
    MOV R8, LARGURA_PEIXE
    MOV R9, ALTURA_PEIXE

	;Define posições do peixe (A) e do prémio (B)
    MOV R1, [linha_peixe]
    MOV R2, [coluna_peixe]
    MOV R3, LINHA_PREMIO
    MOV R4, COLUNA_PREMIO
    MOV R5, DIMENSAO_PREMIO
    MOV R6, DIMENSAO_PREMIO

	;Testa colisão entre peixe e prémio
    CALL testa_colisao
    CMP R0, 1
    JNZ fim_verifica_premio

    ;Colisão confirmada 
    MOV R0, 0
    MOV [visivel_premio], R0
	;Apaga visualmente o prémio
	MOV R0, DEF_PREMIO
	MOV R1, LINHA_PREMIO
	MOV R2, COLUNA_PREMIO
	CALL apaga_objeto
	MOV R6, 32
	MOV [linha_premio], R6
	
	MOV R0,5
	CALL toca_som
	;Ativa reforço de disparo
    MOV R0, 10
    MOV [tiros_reforcados], R0
    MOV R0, ALCANCE_REFORCADO
    MOV [alcance_bala], R0

fim_verifica_premio:
    POP R9
    POP R8
    POP R6
    POP R5
    POP R4
    POP R3
    POP R2
    POP R1
    POP R0
    RET
	




;--------------------TESTA COLISÃO---------------------
; Vai verificar se houve colisão entre dois objetos
; INPUT:
; 	R1 - linha objeto 1
; 	R2 - coluna objeto 1
; 	R3 - linha objeto 2
; 	R4 - coluna objeto 2
; 	R5 - altura do objeto 2
; 	R6 - largura do objeto 2
;   R8 - largura do objeto 1
;   R9 - altura do objeto 1 
;  
; OUTPUT:
; 	R0 = 1 (se ocorreu uma colisão)
; 	R0 = 0 (se não ocorreu colisão)
; Registo:
;   R7 - valor temporário

testa_colisao:
    PUSH R7

    ;verifica se R2 < R4 + R6
    MOV R7, R4
    ADD R7, R6
    CMP R2, R7
    JGE sem_colisao

    ;verifica se R2 + R8 > R4
    MOV R7, R2
    ADD R7, R8
    CMP R7, R4
    JLE sem_colisao

    ;verifica se R1 < R3 + R5
    MOV R7, R3
    ADD R7, R5
    CMP R1, R7
    JGE sem_colisao

    ;verifica se R1 + R9 > R3
    MOV R7, R1
    ADD R7, R9
    CMP R7, R3
    JLE sem_colisao

    ;Ocorreu colisão
    MOV R0, 1
    JMP fim_testa

sem_colisao:
    MOV R0, 0

fim_testa:
    POP R7
    RET


;-------------------DESENHA UM OBJETO--------------------
; Desenha no ecrã um objeto defenido numa tabela de pixeis
; INPUT:
;	R0 - endereço da tabela do objeto (início da tabela)
;	R1 - linha inicial, onde desenhar no ecrã
;	R2 - coluna inicial, onde desenhar no ecrã
; OUTPUT: Desenha o objeto no ecrã a partir da posição [R1, R2]
; Registos:
;	R3 - largura do objeto
;	R4 - altura do objeto
;	R5 - linha atual
;	R6 - coluna atual
;	R7 - cor e posição

desenha_objeto:
    PUSH R3
    PUSH R4
    PUSH R5
    PUSH R6
    PUSH R7

    MOV R3, [R0]
    ADD R0, 2
    MOV R4, [R0]
    ADD R0, 2
    MOV R5, 0

linha_loop:          ;percorre linha a linha
    CMP R5, R4
    JGE fim_desenho
    MOV R6, 0 

coluna_loop:         ;percorre cada coluna
    CMP R6, R3
    JGE proxima_linha
    ;calcula linha real
    MOV R7, R1
    ADD R7, R5
    MOV [DEFINE_LINHA], R7
    ;calcula coluna real
    MOV R7, R2
    ADD R7, R6
    MOV [DEFINE_COLUNA], R7 
	;lê cor do pixel
    MOV R7, [R0]            
    MOV [DEFINE_PIXEL], R7
    ADD R0, 2
    ADD R6, 1
    JMP coluna_loop

proxima_linha: 
    ADD R5, 1
    JMP linha_loop

fim_desenho:
    POP R7
    POP R6
    POP R5
    POP R4
    POP R3
    RET

;-----------------------CONVERTE O ÍNDICE---------------------------
; Converte um valor de linha ou coluna do teclado com um só bit ativo
; INPUT: 
;	R1 - valor da linha ou coluna com um bit ativo(1,2,4 ou 8)
; OUTPUT: 
; 	R0 - índice entre 0 e 3

converte_indice:
    PUSH R1
    MOV R0, 0
converte_loop:
    CMP R1, 1
    JZ fim_converte 
    SHR R1, 1       ;divide por 2
    ADD R0, 1
    JMP converte_loop
;o número de SHR feitos corresponde ao índice final
fim_converte:
    POP R1
    RET
	
;------------------ATRASAR--------------------
; Introduz um atraso em ciclos de clock 
; INPUT:
;	R7 - contador de tempo
; OUTPUT: cria um delay
atrasar:
    PUSH R7
    MOV R7, 0FFFFH
espera_atraso:
    SUB R7, 1
    CMP R7, 0
    JNZ espera_atraso
    POP R7
    RET
	
;-----------------------MOVER PEIXE DIREITA-------------------
; Move o peixe para a direita (cima, diagonal sup_dir, direta, diagonal inf_dir)
; Consoante o valor de R3, atualiza a direção e trata colisões
; INPUT:
;   R3 – direção (inf_dir (R3=4), direita(R3=3), sup_dir(R3=2), cima(R3=1))
;   R1 - linha atual do peixe
;   R2 - coluna atual do peixe
; OUTPUT:
;   Atualiza as variáveis [linha_peixe] e [coluna_peixe] com nova posição válida
;   Desenha o peixe na nova posição, se não houver colisão
;   Caso contrário, redesenha o peixe na posição original
;Registos:
;	R5 - tabela de pixeis do peixe virado para a direita
;   R6 - valor temporário
;   R8 - largura do peixe (para colisão)
;   R9 – altura do peixe (para colisão)
mover_peixe_d:
    PUSH R0
    PUSH R1
    PUSH R2
    PUSH R3
    PUSH R5
    PUSH R6
	PUSH R8
	PUSH R9
	
	;Define a direção como direita
	MOV R6,0
	MOV [direcao_peixe], R6
    ;Apaga o peixe da posição anterior
    MOV R5, DEF_PEIXE_DIR
    MOV R1, [linha_peixe]
    MOV R2, [coluna_peixe]
    MOV R0, R5
    CALL apaga_objeto

    ;Calcula nova posição conforme R3
    CMP R3, 1  ;tecla 1
    JZ cima
	CMP R3,2   ;tecla 2
	JZ sup_dir
	CMP R3,3   ;tecla 6
	JZ direita
	;tecla A
    ADD R1, 1
    ADD R2, 1
    JMP verificar_limite_d
cima:
    SUB R1, 1
	JMP verificar_limite_d
sup_dir:
	SUB R1,1
	ADD R2,1
	JMP verificar_limite_d
direita:
	ADD R2,1

verificar_limite_d:
	
    ;Verifica limites verticais
    CMP R1, 1
    JLT paredes_d
    MOV R6, 28
    CMP R1, R6
    JGT paredes_d

    ;Verifica limites horizontais
    CMP R2, 1
    JLT paredes_d
    MOV R6, 58
    CMP R2, R6
    JGT paredes_d

    ;Verifica colisão com zona proibida
	MOV R8, LARGURA_PEIXE
	MOV R9, ALTURA_PEIXE
    CALL colisao_com_zona_proibida
    CMP R0, 1
    JZ paredes_d
	
	CALL verifica_colisao_premio
	CALL verifica_colisao_peixe_boia
    JMP fim_mover_peixe_d

paredes_d:
    ;Redesenha na posição antiga se há colisão
    MOV R1, [linha_peixe]
    MOV R2, [coluna_peixe]
    MOV R0, R5
    CALL desenha_objeto
    JMP fim_d

fim_mover_peixe_d:
	; Atualiza posição do peixe
    MOV [linha_peixe], R1
    MOV [coluna_peixe], R2
    ; Desenha o peixe na nova posição
    MOV R0, R5
    CALL desenha_objeto
fim_d:
	POP R9
	POP R8
    POP R6
    POP R5
    POP R3
    POP R2
    POP R1
    POP R0
    RET

;-----------------------MOVER PEIXE ESQUERDA--------------------
; Move o peixe para a esquerda (diagonal sup_esq, esq, diagonal inf_esq,baixo)
; Consoante o valor de R3, atualiza a direção e trata colisões
; INPUT:
;   R3 – direção (sup_esq (R3=4), esq(R3=3), inf_esq(R3=2), baixo(R3=1))
;   R1 - linha atual do peixe
;   R2 - coluna atual do peixe
; OUTPUT:
;   Atualiza as variáveis [linha_peixe] e [coluna_peixe] com nova posição válida
;   Desenha o peixe na nova posição, se não houver colisão
;   Caso contrário, redesenha o peixe na posição original
;Registos:
;	R5 - tabela de pixeis do peixe virado para a esquerda
;   R6 - valor temporário
;   R8 - largura do peixe (para colisão)
;   R9 – altura do peixe (para colisão)

mover_peixe_e:
    PUSH R0
    PUSH R1
    PUSH R2
    PUSH R3
    PUSH R5
    PUSH R6
	PUSH R8
	PUSH R9
	
	;Define a direção como esquerda
	MOV R6,1
	MOV [direcao_peixe], R6
    ;Apaga o peixe da posição anterior
    MOV R5, DEF_PEIXE_ESQ
    MOV R1, [linha_peixe]
    MOV R2, [coluna_peixe]
    MOV R0, R5
    CALL apaga_objeto

    ;Calcula nova posição conforme R3
    CMP R3, 1 ;tecla 9
    JZ baixo
	CMP R3,2   ;tecla 8
	JZ inf_esq
	CMP R3,3    ;tecla 4
	JZ esquerda
	;tecla 0
    SUB R1, 1
    SUB R2, 1
    JMP verificar_limite_e

baixo:
    ADD R1, 1
	JMP verificar_limite_e
  inf_esq:
	ADD R1,1
	SUB R2,1
	JMP verificar_limite_e
esquerda:
	SUB R2,1
	
verificar_limite_e:
    ;Verifica limites verticais
    CMP R1, 1
    JLT paredes_e
    MOV R6, 28
    CMP R1, R6
    JGT paredes_e

    ;Verifica limites horizontais
    CMP R2, 1
    JLT paredes_e
    MOV R6, 58
    CMP R2, R6
    JGT paredes_e

    ;Verifica colisão com zona proibida
	MOV R8, LARGURA_PEIXE
	MOV R9, ALTURA_PEIXE
    CALL colisao_com_zona_proibida
    CMP R0, 1
    JZ paredes_e
	CALL verifica_colisao_premio
	CALL verifica_colisao_peixe_boia
	
    JMP fim_mover_peixe_e

paredes_e:
    ;Redesenha na posição antiga se há colisão
    MOV R1, [linha_peixe]
    MOV R2, [coluna_peixe]
    MOV R0, R5
    CALL desenha_objeto
    JMP fim_e

fim_mover_peixe_e:
	; Atualiza posição do peixe
    MOV [linha_peixe], R1
    MOV [coluna_peixe], R2
    ;Desenha o peixe na nova posição
    MOV R0, R5
    CALL desenha_objeto
fim_e:
	POP R9
	POP R8
    POP R6
    POP R5
    POP R3
    POP R2
    POP R1
    POP R0
    RET

;----------------------------APAGA UM OBJETO-----------------------------
; Apaga do ecrã um objeto desenhado, substituindo por cor 0 (transparente)
; INPUT:
; 	R0 - endereço da tabela do objeto
; 	R1 - linha inicial 
; 	R2 - coluna inicial
; OUTPUT: apaga do ecrã o objeto
; Registos:
; 	R3 - largura do objeto
; 	R4 - altura do objeto
; 	R5 - linha atual (contador)
; 	R6 - coluna atual (contador)
; 	R7 - endereço de escrita do pixel

apaga_objeto:
    PUSH R0
    PUSH R1
    PUSH R2
    PUSH R3
    PUSH R4
    PUSH R5
    PUSH R6
    PUSH R7

    MOV R3, [R0]     
    ADD R0, 2
    MOV R4, [R0]     
    ADD R0, 2
    MOV R5, 0       

linha_apaga:
    CMP R5, R4     ;se todas as linhas já foram processadas
    JGE fim_apaga
    MOV R6, 0        
coluna_apaga: 
    CMP R6, R3     ;se todas as colunas da linha atual foram processadas
    JGE prox_linha_apaga

    ;Calcula linha real: linha base + linha relativa
    MOV R7, R1
    ADD R7, R5
    MOV [DEFINE_LINHA], R7

    ;Calcula coluna real: coluna base + coluna relativa
    MOV R7, R2
    ADD R7, R6
    MOV [DEFINE_COLUNA], R7

    ;Escreve pixel com cor 0 (transparente)
    MOV R7, 0
    MOV [DEFINE_PIXEL], R7

    ADD R6, 1
    JMP coluna_apaga

prox_linha_apaga:
    ADD R5, 1
    JMP linha_apaga

fim_apaga:
    POP R7
    POP R6
    POP R5
    POP R4
    POP R3
    POP R2
    POP R1
    POP R0
    RET

;-------------------- INCREMENTA -------------------------------
; Incrementa o valor do contador do jogo e atualiza o display
; Se atingir o valor máximo, termina o jogo.
; INPUT:
;   R1 – valor atual do contador
;   R6 – valor máximo permitido
; OUTPUT: Se contador atingir MAX_CONT:
;   Apaga todods os objetos do ecrã 
;   Flag tempo_ativo = 0 (pausa o jogo)
;   Flag terminou_jogo = 1   

incrementa:
    PUSH R1
    PUSH R6
	
	;Lê e incrementa o contador
    MOV R1, [contador]
    MOV R6, MAX_CONT
    CMP R1, R6
    JGE perder
    ADD R1, 1
    MOV [contador], R1
    MOV R6, R1
    CALL mostra_tempo_jogo
	JMP fim_inc
		
perder:
	CALL apaga_todos_os_objetos
    MOV R0, 0
    MOV [tempo_ativo], R0
	MOV R6, 1
    MOV [terminou_jogo], R6
	
fim_inc:
    POP R6
    POP R1
    RET


;------------------------ MOSTRA_TEMPO_JOGO ------------------------
; Converte o valor do tempo (segundos) em formato decimal (centenas,
; dezenas, unidades) e mostra no display(R4)
; INPUT:
;   R6 - valor do tempo a ser mostrado (0 a 999)
;   R4- endereço do display 
; OUTPUT:
;   [R4] - Mostra valor decimal no display 
; REGISTOS:
;   R0 - valor atual a converter
;   R1 - valor final codificado (HEX)
;   R2 - contador de dezenas
;   R3 - contador de unidades
;   R6 - valor temporário

mostra_tempo_jogo:
    PUSH R0
    PUSH R1
    PUSH R2
    PUSH R3
    PUSH R4
    PUSH R6

    MOV R4, DISPLAYS         
    MOV R6, [tempo_jogo]     
    MOV R0, R6              
    MOV R1, 0                
    MOV R2, 0                
    MOV R3, 0               

; Conta centenas (subtrai 100 até não dar mais)
conta_cent:
    MOV R6, 100
    CMP R0, R6
    JLT conta_dez
    SUB R0, R6
    ADD R1, 1
    JMP conta_cent

; Conta dezenas (subtrai 10 até não dar mais)
conta_dez:
    MOV R6, 10
    CMP R0, R6
    JLT fim_conta
    SUB R0, R6
    ADD R2, 1
    JMP conta_dez

; Resto = unidades
fim_conta:
    MOV R3, R0
    SHL R1, 8        
    SHL R2, 4         
    OR R1, R2        
    OR R1, R3        
    MOV [R4], R1      

    POP R6
    POP R4
    POP R3
    POP R2
    POP R1
    POP R0
    RET

;-------------------------- MOVER_BOIA -------------------------------
; Move uma boia na direção do peixe, primeiro na diagonal e se não der tenta na linha/coluna
; INPUT:
;   R1 – linha atual da boia
;   R2 – coluna atual da boia
;   R3 - linha do peixe 
; OUTPUT:
;   R1 – nova linha da boia 
;   R2 – nova coluna da boia 
;   Apaga a boia da posição anterior
;   Desenha a boia na nova posição (válida)
; Registos:
;   R4 - coluna do peixe
;   R5 - tentativa de nova linha (candidata ao movimento)
;   R6 - tentativa de nova linha (candidata ao movimento)
;   R7 - cópia da coluna antiga da boia 
;   R10 - cópia da linha antiga da boia
mover_boia:
    PUSH R0
    PUSH R3
    PUSH R4
    PUSH R5
    PUSH R6
    PUSH R7    
    PUSH R10    

    ;Apaga a boia antiga da posição atual (R1,R2)
    MOV R6, DEF_BOIA
    MOV R0, R6
    CALL apaga_objeto

    ;Guarda a posição anterior da boia 
    MOV R10, R1      
    MOV R7, R2       

    ;Obtém posição atual do peixe
    MOV R3, [linha_peixe]
    MOV R4, [coluna_peixe]

    ; --------- TENTATIVA MOV. DIAGONAL ---------
	;Calcula nova linha (R5) mais próxima do peixe
    MOV R5, R1     
    CMP R1, R3
    JLT inc_linha_d   ;se boia está acima do peixe, desce
    CMP R1, R3
    JGT dec_linha_d    ;se está abaixo, sobe
    JMP fim_linha_d
inc_linha_d:
    ADD R5, 1
    JMP fim_linha_d
dec_linha_d:
    SUB R5, 1
fim_linha_d:

; Calcula nova coluna (R6) mais próxima do peixe
    MOV R6, R2 
    CMP R2, R4
    JLT inc_col_d    ;se boia está à esquerda do peixe, move à direita
    CMP R2, R4
    JGT dec_col_d    ;se está à direita, move à esquerda
    JMP fim_col_d
inc_col_d:
    ADD R6, 1
    JMP fim_col_d
dec_col_d:
    SUB R6, 1
fim_col_d:

    ;Testa se a nova posição diagonal (R5, R6) é válida
    MOV R1, R5
    MOV R2, R6
    CALL testa_posicao_valida
    CMP R0, 1
    JZ aplicar_movimento_final

    ; --------- TENTATIVA SÓ NA LINHA ---------
    MOV R1, R5   ;linha ajustada
    MOV R2, R7   ;coluna original
    CALL testa_posicao_valida
    CMP R0, 1
    JZ aplicar_movimento_final

    ; --------- TENTATIVA SÓ NA COLUNA ---------
    MOV R1, R10   ;linha original
    MOV R2, R6    ;coluna ajustada
    CALL testa_posicao_valida
    CMP R0, 1
    JZ aplicar_movimento_final

    ; --------- NENHUMA VÁLIDA: voltar à posição anterior ---------
    MOV R1, R10
    MOV R2, R7

aplicar_movimento_final:
    ;Desenha a boia na posição final (seja ela a nova válida ou a antiga)
    MOV R0, DEF_BOIA
    CALL desenha_objeto
    JMP fim_bola


fim_bola:
    POP R10
    POP R7
    POP R6
    POP R5
    POP R4
    POP R3
    POP R0
    RET
	
;-------------------- TESTA_POSICAO_VALIDA -------------------------------
; Verifica se a posição (R1, R2) é válida para posicionar uma boia
; INPUT:
;   R1 – linha a testar
;   R2 – coluna a testar
;   R3 - linha_premio
;   R4 - coluna do prémio
;   R5/R6 - dimensão do prémio
;   R8/R9 - dimensão da boia
; OUTPUT:
;   R0 = 1 se a posição for válida (dentro dos limites e sem colisões)
;   R0 = 0 se a posição for inválida

testa_posicao_valida:
    PUSH R3
    PUSH R4
	PUSH R5
    PUSH R6
    PUSH R8
    PUSH R9

    ;Verifica se R1 (linha) está dentro dos limites do ecrã [1, 27]
    CMP R1, 1
    JLT invalida    ;R1 < 1, é inválida
    MOV R6, 27
    CMP R1, R6
    JGT invalida   ;R1 > 27, é inválida

    ; Verifica se R2 (coluna) está dentro dos limites do ecrã [1, 59]
    CMP R2, 1
    JLT invalida    ;R2 < 1, é inválida
    MOV R6, 59
    CMP R2, R6
    JGT invalida    ;R2 > 59, é inválida

    ;Verifica colisão com zona proibida
    MOV R8, DIMENSAO_BOIA
    MOV R9, DIMENSAO_BOIA
    CALL colisao_com_zona_proibida
    CMP R0, 1
    JZ invalida    
	
	;Premio
	MOV	R3, [linha_premio]
	MOV R4, COLUNA_PREMIO
    MOV R5, DIMENSAO_PREMIO
    MOV R6, DIMENSAO_PREMIO
    CALL testa_colisao
    CMP R0, 1
    JZ invalida    ; se colide com o prémio, é inválida

	; Verifica colisão com outras boias
    CALL colisao_com_outras_boias
    CMP R0, 1
    JZ invalida

    MOV R0, 1
    JMP fim_teste_pos

invalida:
    MOV R0, 0

fim_teste_pos:
    POP R9
    POP R8
    POP R6
	POP R5
    POP R4
    POP R3
    RET

;------------------------ MOVER_TODAS_BOLAS ----------------------------
; Atualiza a posição de todas as boias no ecrã, uma a uma, numa posição válida,
;tentando sempre aproximar-se do peixe
; INPUT:
;   R1 - linha_boia_x (x=1 a 4 ) atual
;   R2 - coluna_boia_x (x=1 a 4 ) atual
; OUTPUT: posições atuais atualizadas 

mover_todas_bolas:
    PUSH R1
    PUSH R2

    ; --------- BOLA 1 ---------
    MOV R1, [linha_boia_1]
    MOV R2, [coluna_boia_1]
    CALL mover_boia
    MOV [linha_boia_1], R1
    MOV [coluna_boia_1], R2

    ; --------- BOLA 2 ---------
    MOV R1, [linha_boia_2]
    MOV R2, [coluna_boia_2]
    CALL mover_boia
    MOV [linha_boia_2], R1
    MOV [coluna_boia_2], R2

    ; --------- BOLA 3 ---------
    MOV R1, [linha_boia_3]
    MOV R2, [coluna_boia_3]
    CALL mover_boia
    MOV [linha_boia_3], R1
    MOV [coluna_boia_3], R2

    ; --------- BOLA 4 ---------
    MOV R1, [linha_boia_4]
    MOV R2, [coluna_boia_4]
    CALL mover_boia
    MOV [linha_boia_4], R1
    MOV [coluna_boia_4], R2

    POP R2
    POP R1
    RET
	
;-------------------- VERIFICA_COLISAO_BOIA_DISPARO -------------------------------
; Verifica colisões entre a bala e as boias no ecrã.
; INPUT:
;   R1 - linha da bala
; 	R2 - coluna da bala
;   R3 - linha_boia_x (x= 1 a 4)
;   R4 - coluna_boia_x (x= 1 a 4)
; 	R5/R6 - DIMENSAO_BOIA
; 	R8/R9 - DIMENSAO_DISPARO
; 	
; OUTPUT:Se houver colisão:
;    A boia atingida é apagada e reposicionada fora do ecrã (linha = 32)
;    Ativa efeito de explosão na posição da boia
;
verifica_colisao_boia_disparo:
    PUSH R0
    PUSH R1
    PUSH R2
    PUSH R3
    PUSH R4
    PUSH R5
    PUSH R6
    PUSH R8
    PUSH R9

    ; posição da bala
    MOV R1, [linha_bala]
    MOV R2, [coluna_bala]
    MOV R8, DIMENSAO_DISPARO
    MOV R9, DIMENSAO_DISPARO

    ; ---------- BOIA 1 ----------
    MOV R3, [linha_boia_1]
    MOV R4, [coluna_boia_1]
    MOV R5, DIMENSAO_BOIA
    MOV R6, DIMENSAO_BOIA
    CALL testa_colisao
    CMP R0, 1
    JZ explodir_boia_1

    ; ---------- BOIA 2 ----------
    MOV R3, [linha_boia_2]
    MOV R4, [coluna_boia_2]
    CALL testa_colisao
    CMP R0, 1
    JZ explodir_boia_2

    ; ---------- BOIA 3 ----------
    MOV R3, [linha_boia_3]
    MOV R4, [coluna_boia_3]
    CALL testa_colisao
    CMP R0, 1
    JZ explodir_boia_3

    ; ---------- BOIA 4 ----------
    MOV R3, [linha_boia_4]
    MOV R4, [coluna_boia_4]
    CALL testa_colisao
    CMP R0, 1
    JZ explodir_boia_4

    JMP fim_colisao_boia_disparo

explodir_boia_1:
    ; Apaga visualmente a boia 1
    MOV R0, DEF_BOIA
    MOV R1, [linha_boia_1]
    MOV R2, [coluna_boia_1]
    CALL apaga_objeto

    ; Mostra explosão
    CALL explodir

    ; Move boia para fora do ecrã
    MOV R1, 32
    MOV [linha_boia_1], R1
    JMP fim_colisao_boia_disparo


explodir_boia_2:
    ; Apaga visualmente a boia 2
    MOV R0, DEF_BOIA
    MOV R1, [linha_boia_2]
    MOV R2, [coluna_boia_2]
    CALL apaga_objeto

    ; Mostra explosão
    CALL explodir

    ; Move boia para fora do ecrã
    MOV R1, 32
    MOV [linha_boia_2], R1
    JMP fim_colisao_boia_disparo


explodir_boia_3:
    ; Apaga visualmente a boia 3
    MOV R0, DEF_BOIA
    MOV R1, [linha_boia_3]
    MOV R2, [coluna_boia_3]
    CALL apaga_objeto

    ; Mostra explosão
    CALL explodir

    ; Move boia para fora do ecrã
    MOV R1, 32
    MOV [linha_boia_3], R1
    JMP fim_colisao_boia_disparo


explodir_boia_4:
    ; Apaga visualmente a boia 4
    MOV R0, DEF_BOIA
    MOV R1, [linha_boia_4]
    MOV R2, [coluna_boia_4]
    CALL apaga_objeto

    ; Mostra explosão
    CALL explodir

    ; Move boia para fora do ecrã
    MOV R1, 32
    MOV [linha_boia_4], R1
    JMP fim_colisao_boia_disparo
	
fim_colisao_boia_disparo:
    CALL verifica_vitoria

    POP R9
    POP R8
    POP R6
    POP R5
    POP R4
    POP R3
    POP R2
    POP R1
    POP R0
    RET
	
;-------------------- EXPLODIR -------------------------------
; Ativa a explosão no ecrã e atualiza os dados associados
; INPUT:  
; 	R1 - posição da explosão (linha)
;	R2 – posição da explosão (coluna)
;       
; OUTPUT:
;    Toca o som (2)
; Registos:
; 	R0/R6: utilizado para atribuições temporárias
explodir:
    PUSH R0
    PUSH R1
    PUSH R2
	PUSH R6

    ;Toca som da explosão
    MOV R0, 2
    CALL toca_som

    ;Desenha a explosão
    MOV R0, DEF_EXPLOSAO
    CALL desenha_objeto

    ;Guarda a posição da explosão
    MOV [linha_explosao], R1
    MOV [coluna_explosao], R2

    ; Ativa flag da explosão, para depois ser apagada
    MOV R0, 1
    MOV [explosao_ativa], R0

    ;Bala desativada quando atinge boia 
    MOV R0, 0
    MOV [bala_ativa], R0
    MOV [passos_bala], R0
	
	POP R6
    POP R2
    POP R1
    POP R0
    RET
;------------------ COLISAO_COM_OUTRAS_BOIAS ------------------
; Verifica se a posição simulada da boia colide com alguma das outras 3 boias.
; INPUT: 
;	R10 - linha simulada da boia atual
;   R7 - coluna simulada da boia atual
; OUTPUT:
;   R0 = 1 se houve colisão com outra boia
;   R0 = 0 se não houve colisão
; Registos:
; 	R3, R4: posição da boia a testar
; 	R5, R6: dimensões da boia testada
; 	R8, R9: dimensões da boia em movimento (para colisão)

colisao_com_outras_boias:
    PUSH R3
    PUSH R4
    PUSH R5
    PUSH R6
    PUSH R8
    PUSH R9

;--- BOIA 1 ---
testa_b1:
	MOV R3, [linha_boia_1]
	MOV R4, [coluna_boia_1]
	;Evita comparar com a própria boia (linha e coluna iguais)
	CMP R10, R3
	JNZ testa_b1a
	CMP R7, R4
	JNZ testa_b1a
	JMP testa_b2   ; mesma boia, ignora
testa_b1a:
	MOV R5, DIMENSAO_BOIA
	MOV R6, DIMENSAO_BOIA
	MOV R8, DIMENSAO_BOIA
	MOV R9, DIMENSAO_BOIA
	CALL testa_colisao
	CMP R0, 1
	JZ encontrou_colisao
	
;--- BOIA 2 ---
testa_b2:
    MOV R3, [linha_boia_2]
    MOV R4, [coluna_boia_2]
	;Evita comparar com a própria boia (linha e coluna iguais)
    CMP R10, R3
    JNZ testa_b2a
    CMP R7, R4
    JNZ testa_b2a
    JMP testa_b3   ; mesma boia, ignora
testa_b2a:
    MOV R5, DIMENSAO_BOIA
    MOV R6, DIMENSAO_BOIA
    MOV R8, DIMENSAO_BOIA
    MOV R9, DIMENSAO_BOIA
    CALL testa_colisao
    CMP R0, 1
    JZ encontrou_colisao
	
;--- BOIA 3 ---
testa_b3:
    MOV R3, [linha_boia_3]
    MOV R4, [coluna_boia_3]
	;Evita comparar com a própria boia (linha e coluna iguais)
    CMP R10, R3
    JNZ testa_b3a
    CMP R7, R4
    JNZ testa_b3a
    JMP testa_b4    ; mesma boia, ignora
testa_b3a:
    MOV R5, DIMENSAO_BOIA
    MOV R6, DIMENSAO_BOIA
    MOV R8, DIMENSAO_BOIA
    MOV R9, DIMENSAO_BOIA
    CALL testa_colisao
    CMP R0, 1
    JZ encontrou_colisao
	
;--- BOIA 4 ---
testa_b4:
    MOV R3, [linha_boia_4]
    MOV R4, [coluna_boia_4]
	;Evita comparar com a própria boia (linha e coluna iguais)
    CMP R10, R3
    JNZ testa_b4a
    CMP R7, R4
    JNZ testa_b4a
    JMP boias_nao_colidem    ; mesma boia, ignora
testa_b4a:
    MOV R5, DIMENSAO_BOIA
    MOV R6, DIMENSAO_BOIA
    MOV R8, DIMENSAO_BOIA
    MOV R9, DIMENSAO_BOIA
    CALL testa_colisao
    CMP R0, 1
    JZ encontrou_colisao
	
boias_nao_colidem:
    MOV R0, 0
    JMP fim_colisao_boias

encontrou_colisao:
    MOV R0, 1

fim_colisao_boias:
    POP R9
    POP R8
    POP R6
    POP R5
    POP R4
    POP R3
    RET
	
;------------ VERIFICA_COLISAO_PEIXE_BOIA ------------
; Verifica se o peixe colide com alguma das 4 boias.
; INPUT:
;   R1 - linha do peixe
;   R2 - coluna do peixe
;   R3 - linha da boia (1 a 4)
;   R4 - coluna da boia (1 a 4)
;   R5 - largura da boia (DIMENSAO_BOIA)
;   R6 - altura da boia (DIMENSAO_BOIA)
;   R8 - largura do peixe (LARGURA_PEIXE)
;   R9 - altura do peixe (ALTURA_PEIXE)
; OUTPUT: Em caso de colisão:
;   R0 = 1 (se houve colisão)
;   Apaga todos os objetos
;   Mostra imagem de fundo (2)
;   Toca o som (3)
;   Flag tempo_ativo -(0)
;   Flag terminou_jogo -(1)

verifica_colisao_peixe_boia:
	PUSH R0
    PUSH R1
    PUSH R2
    PUSH R3
    PUSH R4
    PUSH R5
    PUSH R6
    PUSH R8
    PUSH R9
	
	;Define dimensões do peixe e guarda a sua posição
    MOV R8, LARGURA_PEIXE
    MOV R9, ALTURA_PEIXE
    MOV R1, [linha_peixe]
    MOV R2, [coluna_peixe]

    ;--- BOIA 1 ---
    MOV R3, [linha_boia_1]
    MOV R4, [coluna_boia_1]
    MOV R5, DIMENSAO_BOIA
    MOV R6, DIMENSAO_BOIA
    CALL testa_colisao
    CMP R0, 1
    JZ perdeu_jogo

    ;--- BOIA 2 ---
    MOV R3, [linha_boia_2]
    MOV R4, [coluna_boia_2]
    CALL testa_colisao
    CMP R0, 1
    JZ perdeu_jogo

    ;--- BOIA 3 ---
    MOV R3, [linha_boia_3]
    MOV R4, [coluna_boia_3]
    CALL testa_colisao
    CMP R0, 1
    JZ perdeu_jogo

    ;--- BOIA 4 ---
    MOV R3, [linha_boia_4]
    MOV R4, [coluna_boia_4]
    CALL testa_colisao
    CMP R0, 1
    JZ perdeu_jogo

    JMP fim_colisao_boia   ; não colidiu com nenhuma

perdeu_jogo:
	CALL apaga_todos_os_objetos
    MOV R0, 2
    CALL mostra_imagem_fundo
	MOV R0,3
	CALL toca_som
    MOV R0, 0
    MOV [tempo_ativo], R0

;espera_reinicio
	MOV R6, 1
    MOV [terminou_jogo], R6

fim_colisao_boia:
    POP R9
    POP R8
    POP R6
    POP R5
    POP R4
    POP R3
    POP R2
    POP R1
	POP R0
    RET
	
;--------------------- VERIFICA_VITORIA -----------------------
; Verifica se todas as boias foram removidas (isto é, se a sua linha = 32).
; INPUT:
;   R0 - leitura de linha da boia (usado iterativamente)
;   R6 - valor fixo de linha fora do ecrã (= 32)
; OUTPUT: Se todas as boias estiverem na linha 32:
;   Chamada a apaga_todos_os_objetos
;   Mostra a imagem de fundo (3)
;   Toca o som (4)
;   Flag tempo_ativo (0)
;   Flag terminou_jogo (1)

verifica_vitoria:
    PUSH R0
	PUSH R6

    ; Verifica se todas as boias estão fora do ecrã  
	MOV R0, [linha_boia_1]
	MOV R6,32
    CMP R0, R6
    JNZ fim_verifica_vitoria
    MOV R0, [linha_boia_2]
    MOV R6,32
    CMP R0, R6
    JNZ fim_verifica_vitoria
    MOV R0, [linha_boia_3]
    MOV R6,32
    CMP R0, R6
    JNZ fim_verifica_vitoria
    MOV R0, [linha_boia_4]
    MOV R6,32
    CMP R0, R6
    JNZ fim_verifica_vitoria  ;não ganhou

    ;Ganhou o jogo
    CALL apaga_todos_os_objetos
    MOV R0, 3
    CALL mostra_imagem_fundo
	MOV R0,4
	CALL toca_som
    MOV R0, 0
    MOV [tempo_ativo], R0

    ;Espera_reinicio
	MOV R6, 1
    MOV [terminou_jogo], R6

fim_verifica_vitoria:
	POP R6
    POP R0
    RET

;------------------- APAGA_TODOS_OS_OBJETOS -------------------
; Percorre todas as posições visíveis do ecrã (exceto as bordas)
; e escreve pixels transparentes (cor 0), "limpando" tudo.
; INPUT: 
;	R1 - linha atual (inicia em 1 e vai até 30)
;   R2 - coluna atual (inicia em 1 e vai até 62)
;   R3 - cor a escrever (0 = transparente)
; OUTPUT: todas as posições internas do ecrã são apagadas (menos moldura)
;Registo:
; 	R6 - utilizado para atribuições temporárias

apaga_todos_os_objetos:
    PUSH R1
    PUSH R2
    PUSH R3
	PUSH R6

    MOV R1, 1          ; linha = 1 (não apaga linha 0)
apaga_linha:
	MOV R6, 31
    CMP R1, R6         ; até linha 30 (não apaga linha 31)
    JGE fim_apaga_tudo
    MOV R2, 1          ; coluna = 1 (não apaga coluna 0)
apaga_coluna:
	MOV R6, 63
    CMP R2, R6         ; até coluna 62 (não apaga coluna 63)
    JGE prox_linha
    MOV [DEFINE_LINHA], R1
    MOV [DEFINE_COLUNA], R2
    MOV R3, 0            
    MOV [DEFINE_PIXEL], R3
    ADD R2, 1
    JMP apaga_coluna
prox_linha:
    ADD R1, 1
    JMP apaga_linha

fim_apaga_tudo:
	POP R6
    POP R3
    POP R2
    POP R1
    RET

;--------------------- RESET_VARIAVEIS -----------------------
; Reinicializa todas as variáveis globais para o estado inicial do jogo
; INPUT: nenhum (rotina chamada após carregar em 'C' para reiniciar)
; OUTPUT: todas as variáveis de estado global são postas com o valor inicial
;Registo interno:
; 	R0: utilizado para atribuições temporárias
reset_variaveis:
    PUSH R0

    MOV R0, 0
    MOV [tempo_jogo], R0
    MOV [tempo_ativo], R0
    MOV [bala_ativa], R0
    MOV [passos_bala], R0
    MOV [explosao_ativa], R0
    MOV [executar_tecla_flag], R0
    MOV [mover_bolas_flag], R0
    MOV [mover_bala_flag], R0
    MOV [tiros_reforcados], R0
    MOV [contador], R0
    MOV [em_pausa], R0
    MOV [direcao_peixe], R0

    ;Prémio visível
    MOV R0, 1
    MOV [visivel_premio], R0
	MOV [visivel_premio_backup], R0  
	MOV R0, LINHA_PREMIO
	MOV [linha_premio], R0
	MOV [linha_premio_backup], R0   
	MOV R0, COLUNA_PREMIO
	MOV [coluna_premio], R0
	MOV [coluna_premio_backup], R0  

    ;Reposiciona o peixe
    MOV R0, LINHA_CENTRO
    MOV [linha_peixe], R0
    MOV R0, COLUNA_CENTRO
    MOV [coluna_peixe], R0

    ;Reposiciona boias
    MOV R0, LINHA_BOIA_1
    MOV [linha_boia_1], R0
    MOV R0, COLUNA_BOIA_1
    MOV [coluna_boia_1], R0
    MOV R0, LINHA_BOIA_2
    MOV [linha_boia_2], R0
    MOV R0, COLUNA_BOIA_2
    MOV [coluna_boia_2], R0
    MOV R0, LINHA_BOIA_3
    MOV [linha_boia_3], R0
    MOV R0, COLUNA_BOIA_3
    MOV [coluna_boia_3], R0
    MOV R0, LINHA_BOIA_4
    MOV [linha_boia_4], R0
    MOV R0, COLUNA_BOIA_4
    MOV [coluna_boia_4], R0

    POP R0
    RET
	
;...........Rotinas relacionadas com a pausa do jogo...........

;------------------ DESENHA_ESTADO_JOGO ------------------
; Redesenha todos os elementos do jogo nas posições atuais
; armazenadas nas variáveis principais 
; INPUT:
;   R0 - tabela de piexeis do objeto a desenhar
;   R1 - linha onde o objeto será desenhado
;   R2 - coluna onde o objeto será desenhado
; OUTPUT: Todos os objetos são desenhados nas respetivas posições atuais no ecrã

desenha_estado_jogo:
    PUSH R0
    PUSH R1
    PUSH R2

    ;Desenha o peixe para o último lado que assumiu 
    MOV R1, [direcao_peixe]
	CMP R1, 0
	JZ peixe_direita
	; Se não for 0, então está virado para a esquerda
	MOV R0, DEF_PEIXE_ESQ
	JMP desenha_peixe
peixe_direita:
	MOV R0, DEF_PEIXE_DIR
desenha_peixe:
	MOV R1, [linha_peixe]
	MOV R2, [coluna_peixe]
	CALL desenha_objeto

    ;Desenha as boias
    MOV R0, DEF_BOIA
    MOV R1, [linha_boia_1]
    MOV R2, [coluna_boia_1]
    CALL desenha_objeto
    MOV R1, [linha_boia_2]
    MOV R2, [coluna_boia_2]
    CALL desenha_objeto
    MOV R1, [linha_boia_3]
    MOV R2, [coluna_boia_3]
    CALL desenha_objeto
    MOV R1, [linha_boia_4]
    MOV R2, [coluna_boia_4]
    CALL desenha_objeto

    ;Zonas proibidas fixas
    MOV R0, DEF_ZP_1
    MOV R1, LINHA_ZP_1
    MOV R2, COLUNA_ZP_1
    CALL desenha_objeto
    MOV R0, DEF_ZP_2
    MOV R1, LINHA_ZP_2
    MOV R2, COLUNA_ZP_2
    CALL desenha_objeto
    MOV R0, DEF_ZP_3
    MOV R1, LINHA_ZP_3
    MOV R2, COLUNA_ZP_3
    CALL desenha_objeto
    MOV R0, DEF_ZP_4
    MOV R1, LINHA_ZP_4
    MOV R2, COLUNA_ZP_4
    CALL desenha_objeto

    ;Desenha prémio só se visível
    MOV R0, [visivel_premio]
    CMP R0, 1
    JNZ ignora_premio

    MOV R0, DEF_PREMIO
    MOV R1, [linha_premio]
    MOV R2, [coluna_premio]
    CALL desenha_objeto

ignora_premio:
    CALL desenha_moldura
    POP R2
    POP R1
    POP R0
    RET

;-------------------- GUARDAR_ESTADO_JOGO ---------------------
; Guarda o estado atual do jogo (peixe, boias, prémio e contador)
; em variáveis de backup, para permitir restaurar após uma pausa
; INPUT: 
;	R1 - Estado atual do jogo nas variáveis principais
; OUTPUT: Todos esses valores são copiados para variáveis de backup
guardar_estado_jogo:

    ;Guardar posição do peixe
    MOV R1, [linha_peixe]
    MOV [linha_peixe_backup], R1
    MOV R1, [coluna_peixe]
    MOV [coluna_peixe_backup], R1
	MOV R1, [direcao_peixe]
	MOV [direcao_peixe_backup], R1


    ;Guardar posições das 4 boias
    MOV R1, [linha_boia_1]
    MOV [linha_boia_1_backup], R1
    MOV R1, [coluna_boia_1]
    MOV [coluna_boia_1_backup], R1
    MOV R1, [linha_boia_2]
    MOV [linha_boia_2_backup], R1
    MOV R1, [coluna_boia_2]
    MOV [coluna_boia_2_backup], R1
    MOV R1, [linha_boia_3]
    MOV [linha_boia_3_backup], R1
    MOV R1, [coluna_boia_3]
    MOV [coluna_boia_3_backup], R1
    MOV R1, [linha_boia_4]
    MOV [linha_boia_4_backup], R1
    MOV R1, [coluna_boia_4]
    MOV [coluna_boia_4_backup], R1

    ;Guardar estado do prémio
    MOV R1, [linha_premio]
    MOV [linha_premio_backup], R1
    MOV R1, [coluna_premio]
    MOV [coluna_premio_backup], R1
    MOV R1, [visivel_premio]
    MOV [visivel_premio_backup], R1

    ;Guardar valor atual do contador de tiro
    MOV R1, [contador]
    MOV [contador_backup], R1
    RET

;-------------------- RESTAURAR_ESTADO_JOGO ---------------------
; Restaura todas as variáveis do estado do jogo que foram guardadas
; antes de entrar em pausa (para que o jogo continue de onde parou).
; INPUT: 
;	R1 - Todos os backups guardados anteriormente
; OUTPUT: Estado do jogo restaurado nas variáveis principais

restaurar_estado_jogo:

    ;Restaura a posição do peixe
    MOV R1, [linha_peixe_backup]
    MOV [linha_peixe], R1
    MOV R1, [coluna_peixe_backup]
    MOV [coluna_peixe], R1
	MOV R1, [direcao_peixe_backup]
	MOV [direcao_peixe], R1


    ;Restaura as posições das 4 boias
    MOV R1, [linha_boia_1_backup]
    MOV [linha_boia_1], R1
    MOV R1, [coluna_boia_1_backup]
    MOV [coluna_boia_1], R1
    MOV R1, [linha_boia_2_backup]
    MOV [linha_boia_2], R1
    MOV R1, [coluna_boia_2_backup]
    MOV [coluna_boia_2], R1
    MOV R1, [linha_boia_3_backup]
    MOV [linha_boia_3], R1
    MOV R1, [coluna_boia_3_backup]
    MOV [coluna_boia_3], R1
    MOV R1, [linha_boia_4_backup]
    MOV [linha_boia_4], R1
    MOV R1, [coluna_boia_4_backup]
    MOV [coluna_boia_4], R1

    ;Restaura a posição e visibilidade do prémio
    MOV R1, [linha_premio_backup]
    MOV [linha_premio], R1
    MOV R1, [coluna_premio_backup]
    MOV [coluna_premio], R1
    MOV R1, [visivel_premio_backup]
    MOV [visivel_premio], R1

    ;Restaura o valor do contador (utilizado no número de tiros)
    MOV R1, [contador_backup]
    MOV [contador], R1
    RET

; ---------------------------------------------------------------
; *********************** INTERRUPÇÕES*************************
; ---------------------------------------------------------------
	
;-------------------- ROTINA_INT0 -------------------------------
; INT0: Interrupção ligada ao relógio das boias (mantem as boias em constante movimento)
; INPUT: [tempo_tecla]: contador da duração da tecla pressionada
;        [tecla_anterior]: última tecla detetada 
;
; OUTPUT: [tempo_tecla]: incrementado/reiniciado
;         [executar_tecla_flag]: Se tecla pressionada >= 4 ciclos, fica 1
;         [mover_bolas_flag]: fica 1 a cada chamada (move as boias)

rotina_int0:
    PUSH R0
    PUSH R6
    PUSH R7

    ;Atualiza o temporizador da tecla
    MOV R0, [tempo_tecla]
    ADD R0, 1
    MOV [tempo_tecla], R0

    ;Verifica se há tecla ativa
    MOV R6, [tecla_anterior]
    MOV R7, 0FFF8H            ;0FFF8H = "sem tecla"
    CMP R6, R7
    JZ marcar_flag_bolas    

    ;Ativa a flag se tecla pressionada >= 4 ciclos
    CMP R0, 4
    JLT marcar_flag_bolas
    MOV R7, 0
    MOV [tempo_tecla], R7 ;reinicia o tempo da tecla

    ;Marca flag para executar_tecla
    MOV R6, 1
    MOV [executar_tecla_flag], R6

marcar_flag_bolas:
	;Marca a flag para mover todas as boias no ciclo principal
    MOV R6, 1
    MOV [mover_bolas_flag], R6

fim_int:
    POP R7
    POP R6
    POP R0
    RFE

;-------------------- ROTINA_INT1 -------------------------------
; INT1: Interrupção ligada ao relógio de jogo (conta tempo jogo)
; INPUT: [tempo_ativo]: 0 se cronómetro ativo, 1 caso contrário
;        [tempo_jogo]: valor atual do tempo 
;		 MAX_CONT: tempo máximo de jogo
;
; OUTPUT: [tempo_jogo]: incrementado se tempo ativo
;         [tempo_ativo]: fica 0 se atingir o tempo máximo
;         [terminou_jogo]: fica 1 quando chega a MAX_CONT
;         [apagar_tudo_flag]: fica 1 para sinalizar a limpeza do ecrã
;         [mostrar_imagem_fim_flag]:fica 1 para sinalizar o fim do jogo
;         [atualizar_display_tempo]:fica 1 quando tempo é atualizado

rotina_int1:
    PUSH R0
    PUSH R1

    ;Verifica se o tempo está ativo
    MOV R0, [tempo_ativo]
    CMP R0, 1
    JNZ fim_int1   ;se não está,sai

    ;Incrementa tempo total de jogo
    MOV R1, [tempo_jogo]
    ADD R1, 1
    MOV [tempo_jogo], R1
    ;Verifica se atingiu tempo máximo
	MOV R6,MAX_CONT
    CMP R1, R6
    JNZ nao_atingiu 
    CALL mostra_tempo_jogo  ;atingiu

    ; Sinaliza fim do jogo
    MOV R0, 0
    MOV [tempo_ativo], R0  
    MOV R0, 1
    MOV [terminou_jogo], R0
    MOV [apagar_tudo_flag], R0
    MOV [mostrar_imagem_fim_flag], R0
    JMP fim_int1
nao_atingiu:
    ; Atualiza display no ciclo principal
    MOV R0, 1
    MOV [atualizar_display_tempo], R0

fim_int1:
    POP R1
    POP R0
    RFE

;-------------------- ROTINA_INT2 ---------------------
; INT2: interrupção ligada ao relógio da explosão (apaga-a)
; INPUT: [explosao_ativa]: fica 1 se explosão é visível
;        [linha_explosao]: linha onde ocorreu a explosão
;        [coluna_explosao]: coluna onde ocorreu a explosão
;
; OUTPUT: [apagar_explosao_flag]: fica 1 se explosão estiver ativa
;         [explosao_ativa]: fica 0 quando explosão é apagada

rotina_int2:
    PUSH R0
    PUSH R1
    PUSH R2

    ;Verifica se explosão está ativa
    MOV R0, [explosao_ativa]
    CMP R0, 1
    JNZ fim_int2  ;se não está,sai

    ;Prepara dados para apagar a explosão
    MOV R0, DEF_EXPLOSAO
    MOV R1, [linha_explosao]
    MOV R2, [coluna_explosao]
	;Marca flag para apagar a explosão no ciclo principal
    MOV R0, 1
	MOV [apagar_explosao_flag], R0
    ; Limpa flag da explosão (não está ativa)
    MOV R0, 0
    MOV [explosao_ativa], R0

fim_int2:
    POP R2
    POP R1
    POP R0
    RFE

;-------------------- ROTINA_INT3 ---------------------
; INT3: Ligada ao relógio disponível (ativa movimento do disparo)
; OUTPUT: [mover_bala_flag]: fica 1 para mover a bala no ciclo principal

rotina_int3:
PUSH R0
	;Ativa a flag que sinaliza que a bala deve ser movida
    MOV R0, 1
    MOV [mover_bala_flag], R0

    POP R0
    RFE
	
; ---------------------------------------------------------------
; *********************** FIM DO CÓDIGO *************************
; ---------------------------------------------------------------
	
