# Assembly Arcade Game

Academic project developed for the Computer Architecture course at Instituto Superior Técnico.

The project consists of an arcade game implemented in Assembly for the SEPE simulator, featuring player movement, shooting mechanics, collision detection, moving objects, hardware interrupts, sound effects and game state management.

## Technologies
- Assembly
- SEPE Simulator
- Computer Architecture
- Hardware Interrupts

## Repository structure
- `game.asm` — game source code
- `game.cir` — SEPE circuit configuration
- `assets/images/` — game screens and background
- `assets/audio/` — sound effects
